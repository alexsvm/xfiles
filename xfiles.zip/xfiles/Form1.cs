﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using Microsoft.DirectX.DirectInput;

namespace xfiles
{
    public partial class Form1 : Form
    {
        float dcmin = 1, dcmax = 10;
        Color bc;
        Microsoft.DirectX.Direct3D.Device dr;
        Microsoft.DirectX.DirectInput.Device di = new Microsoft.DirectX.DirectInput.Device(SystemGuid.Keyboard);
        PresentParameters ppr = new PresentParameters();
        Mesh mym;
        Texture[] texmym;
        ExtendedMaterial[] data;
        //cp – вектор камеры
        //cp0 – вектор камеры при нажатии ПКМ
        //ct – вектор цели
        //ct0 – вектор цели при нажатии ПКМ
        //ctm – центр сцены
        //cup – вектор направления вверх
        //cup0 – вектор направления вверх при нажатии ПКМ
        Vector3 cp = new Vector3(3, 0, 0), cp0, ct = new Vector3(0, 0, 0), ct0, cup = new Vector3(0, 0, 1), cup0, ctm;
        Vector3 cl = new Vector3(3, 3, 0), cl0;
        Point cur0; //Положение указателя при нажатии ПКМ
        float pi = (float)Math.PI;

        public Form1()
        {
            InitializeComponent();
            this.MouseWheel += new MouseEventHandler(Form1_MouseWheel);
            bc = this.BackColor;

            di.Acquire();
        }

        //Инициализация 3D устройства Low
        private bool InitializeGraphicsL()
        {
            try
            {
                ppr.Windowed = true; //Оконный режим
                ppr.SwapEffect = SwapEffect.Discard; //Гарантированный режим переключения заднего буфера
                ppr.EnableAutoDepthStencil = true; //Активация буфера глубины и трафарета
                ppr.AutoDepthStencilFormat = DepthFormat.D16; //Формат буфера глубины и трафарета
                ppr.MultiSample = MultiSampleType.None; //Без сглаживания
                //Попытка создать 3D устройство с программной обработкой вершин
                dr = new Microsoft.DirectX.Direct3D.Device(0, Microsoft.DirectX.Direct3D.DeviceType.Hardware, this, CreateFlags.SoftwareVertexProcessing, ppr);
                return true;
            }
            catch
            {
                return false;
            }
        }

        //Инициализация 3D устройства Hi
        private bool InitializeGraphicsH()
        {
            try
            {
                ppr.Windowed = true;
                ppr.SwapEffect = SwapEffect.Discard;
                ppr.EnableAutoDepthStencil = true;
                ppr.AutoDepthStencilFormat = DepthFormat.D24S8;
                ppr.MultiSample = MultiSampleType.FourSamples; //Четвертый уровень сглаживания
                //Попытка создать 3D устройство с аппаратной обработкой вершин
                dr = new Microsoft.DirectX.Direct3D.Device(0, Microsoft.DirectX.Direct3D.DeviceType.Hardware, this, CreateFlags.HardwareVertexProcessing, ppr);
                return true;
            }
            catch
            {
                return false;
            }
        }

        //Загрузка формы
        private void Form1_Load(object sender, EventArgs e)
        {
            //Попытка инициализации 3D устройства
            if (!this.InitializeGraphicsH())
            {
                if (!this.InitializeGraphicsL())
                {
                    MessageBox.Show("Невозможно инициализировать Direct3D устройство. Программа будет закрыта.");
                    this.Close();
                }
            }
            timer1.Enabled = true; //Включение таймера
        }

        //Обзор мышкой
        private void Form1_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            Vector3 cpt = cp0 - ct0;
            //Облет вокруг цели
            if (e.Button == MouseButtons.Right)
            {
                if (di.GetCurrentKeyboardState()[Key.LeftShift]) // Если зажат левый Shift - вражаем второй источник света
                {
                    float alpha = (float)(e.X - cur0.X) / this.ClientSize.Width * pi;
                    float beta = (float)(e.Y - cur0.Y) / this.ClientSize.Height * pi;
                    cl = Vector3.TransformCoordinate(cl0, Matrix.RotationAxis(Vector3.Cross(cpt, cl0), beta) * Matrix.RotationAxis(cl0, -alpha));
                }
                else
                {
                    float alpha = (float)(e.X - cur0.X) / this.ClientSize.Width * pi;
                    float beta = (float)(e.Y - cur0.Y) / this.ClientSize.Height * pi;
                    cup = Vector3.TransformCoordinate(cup0, Matrix.RotationAxis(Vector3.Cross(cpt, cup0), beta));
                    cp = Vector3.TransformCoordinate(cpt, Matrix.RotationAxis(Vector3.Cross(cpt, cup0), beta) * Matrix.RotationAxis(cup, -alpha)) + ct0;
                }
            }

            //Панорамирование
            if (e.Button == MouseButtons.Middle)
            {
                float kd = this.ClientSize.Height / Vector3.Length(cp0);
                float dx = (float)(e.X - cur0.X) / kd;
                float dy = (float)(e.Y - cur0.Y) / kd;
                Vector3 dc = cup0 * dy + Vector3.Normalize(Vector3.Cross(cpt, cup0)) * dx;
                ct = ct0 + dc;
                cp = cp0 + dc;
            }
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            cur0 = e.Location;
            cp0 = cp;
            cup0 = cup;
            ct0 = ct;
            cl0 = cl;
        }

        //Приближение/удаление роликом
        private void Form1_MouseWheel(object sender, MouseEventArgs e)
        {
            Vector3 cpt = cp - ct;
            float dc = cpt.Length();
            if (e.Delta < 0)
            {
                if (dc > dcmin) cpt = cpt * 0.9f;
            }
            if (e.Delta > 0)
            {
                if (dc < dcmax) cpt = cpt * 1.1f;
            }
            cp = ct + cpt;
        }

        //Вывод по таймеру
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (mym == null) return;
            try
            {
                dr.BeginScene();

                float ar = (float)this.ClientSize.Width / (float)this.ClientSize.Height;
                dr.RenderState.Lighting = true;
                dr.RenderState.ZBufferEnable = true;
                dr.RenderState.NormalizeNormals = true;

                //Прозрачность
                dr.RenderState.AlphaBlendEnable = true;
                dr.RenderState.AlphaTestEnable = true;
                dr.RenderState.ReferenceAlpha = 15;
                dr.RenderState.AlphaFunction = Compare.Greater;
                dr.RenderState.SourceBlend = Blend.SourceAlpha;
                dr.RenderState.DestinationBlend = Blend.InvSourceAlpha;
                dr.Transform.Projection = Matrix.PerspectiveFovRH(pi / 4f, ar, dcmin / 2, dcmax * 2);

                //Освещение
                dr.Lights[0].Type = LightType.Directional;
                dr.Lights[0].Diffuse = System.Drawing.Color.White;
                dr.Lights[0].Direction = ct - cp;
                dr.Lights[0].Enabled = true;
                dr.Lights[1].Type = LightType.Directional;
                dr.Lights[1].Diffuse = System.Drawing.Color.Red;
                dr.Lights[1].Direction = cl;
                dr.Lights[1].Enabled = true;

                dr.Clear(ClearFlags.ZBuffer | ClearFlags.Target, bc, 1f, 0);
                dr.Transform.View = Matrix.LookAtRH(cp, ct, cup);
                dr.RenderState.FillMode = (ребраToolStripMenuItem.Text == "Ребра") ? FillMode.Solid : FillMode.WireFrame; //Треугольники/Ребра
                dr.RenderState.CullMode = Cull.CounterClockwise;
                for (int i = 0; i < data.Length; i++)
                {
                    dr.Material = data[i].Material3D;
                    dr.SetTexture(0, texmym[i]);
                    mym.DrawSubset(i);
                }
                dr.RenderState.CullMode = Cull.Clockwise;
                for (int i = 0; i < data.Length; i++)
                {
                    dr.Material = data[i].Material3D;
                    dr.SetTexture(0, texmym[i]);
                    mym.DrawSubset(i);
                }

                dr.EndScene();
                dr.Present();
            }
            catch
            {
                this.Close();
            }
        }

        //Загрузка
        private void m11_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Файлы X(*.x)|*.x";
            openFileDialog1.FileName = "";
            if (openFileDialog1.ShowDialog() == DialogResult.OK && openFileDialog1.FileName.Length > 0)
            {
                if (mym != null)
                {
                    mym.Dispose();
                    for (int i = 0; i < data.Length; i++)
                    {
                        if (texmym[i] != null) texmym[i].Dispose();
                    }
                }
                try
                {
                    mym = Mesh.FromFile(openFileDialog1.FileName, MeshFlags.Managed, dr, out data);
                    GraphicsStream vertexdata = mym.VertexBuffer.Lock(0, mym.VertexBuffer.Description.Size, LockFlags.None);
                    dcmin = Geometry.ComputeBoundingSphere(vertexdata, mym.NumberVertices, mym.VertexFormat, out ctm);
                    mym.VertexBuffer.Unlock();
                    this.Text = openFileDialog1.FileName;
                    m22_Click(null, null);
                }
                catch
                {
                    MessageBox.Show("Ошибка при загрузке файла X");
                    return;
                }
                ct = ctm;
                cp = ct + new Vector3(dcmin * 3, 0, 0);
                dcmax = dcmin * 10;
                if ((data != null) && (data.Length > 0))
                {
                    texmym = new Texture[data.Length];
                    for (int i = 0; i < data.Length; i++)
                    {
                        if ((data[i].TextureFilename != null) && (data[i].TextureFilename != ""))
                        {
                            try
                            {
                                texmym[i] = TextureLoader.FromFile(dr, openFileDialog1.FileName.Replace(openFileDialog1.SafeFileName, data[i].TextureFilename));
                            }
                            catch
                            {
                                MessageBox.Show("Ошибка при загрузке текстуры");
                            }
                        }
                    }
                }
            }
        }

        //Фон
        private void m27_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                bc = colorDialog1.Color;
            }
        }

        //Исходное положение камеры
        private void m22_Click(object sender, EventArgs e)
        {
            ct = ctm;
            cp = ct + new Vector3(dcmin * 3, 0, 0);
            cup = new Vector3(0, 0, 1);
            cl = new Vector3(3, 3, 0);
        }

        //Выход
        private void m12_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //Ребра/Треугольники
        private void ребраToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ребраToolStripMenuItem.Text = (ребраToolStripMenuItem.Text == "Ребра") ? "Треугольники" : "Ребра";
        }
    }
}
