﻿namespace xfiles
{
    partial class Form1
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.m1 = new System.Windows.Forms.ToolStripMenuItem();
            this.m11 = new System.Windows.Forms.ToolStripMenuItem();
            this.m12 = new System.Windows.Forms.ToolStripMenuItem();
            this.m2 = new System.Windows.Forms.ToolStripMenuItem();
            this.m27 = new System.Windows.Forms.ToolStripMenuItem();
            this.m22 = new System.Windows.Forms.ToolStripMenuItem();
            this.ребраToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.m1,
            this.m2});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(784, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // m1
            // 
            this.m1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.m11,
            this.m12});
            this.m1.Name = "m1";
            this.m1.Size = new System.Drawing.Size(48, 20);
            this.m1.Text = "Файл";
            // 
            // m11
            // 
            this.m11.Name = "m11";
            this.m11.Size = new System.Drawing.Size(121, 22);
            this.m11.Text = "Открыть";
            this.m11.Click += new System.EventHandler(this.m11_Click);
            // 
            // m12
            // 
            this.m12.Name = "m12";
            this.m12.Size = new System.Drawing.Size(121, 22);
            this.m12.Text = "Выход";
            this.m12.Click += new System.EventHandler(this.m12_Click);
            // 
            // m2
            // 
            this.m2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.m27,
            this.m22,
            this.ребраToolStripMenuItem});
            this.m2.Name = "m2";
            this.m2.Size = new System.Drawing.Size(79, 20);
            this.m2.Text = "Настройки";
            // 
            // m27
            // 
            this.m27.Name = "m27";
            this.m27.Size = new System.Drawing.Size(239, 22);
            this.m27.Text = "Фон";
            this.m27.Click += new System.EventHandler(this.m27_Click);
            // 
            // m22
            // 
            this.m22.Name = "m22";
            this.m22.Size = new System.Drawing.Size(239, 22);
            this.m22.Text = "Исходное положение камеры";
            this.m22.Click += new System.EventHandler(this.m22_Click);
            // 
            // ребраToolStripMenuItem
            // 
            this.ребраToolStripMenuItem.Name = "ребраToolStripMenuItem";
            this.ребраToolStripMenuItem.Size = new System.Drawing.Size(239, 22);
            this.ребраToolStripMenuItem.Text = "Ребра";
            this.ребраToolStripMenuItem.Click += new System.EventHandler(this.ребраToolStripMenuItem_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 562);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseMove);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem m1;
        private System.Windows.Forms.ToolStripMenuItem m11;
        private System.Windows.Forms.ToolStripMenuItem m2;
        private System.Windows.Forms.ToolStripMenuItem m27;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.ToolStripMenuItem m22;
        private System.Windows.Forms.ToolStripMenuItem m12;
        private System.Windows.Forms.ToolStripMenuItem ребраToolStripMenuItem;
    }
}

